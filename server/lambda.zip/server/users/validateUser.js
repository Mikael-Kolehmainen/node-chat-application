const bcrypt = require("bcrypt");
const { AWS } = require("../AWS");

exports.handler = async (event, context) => {
  const docClient = new AWS.DynamoDB.DocumentClient();
  /*
    1. Get user from dynamodb with username, if not found return to front-end not found
    2. Compare passwords with bcrypt, if not the same return to front-end not the same
  */
  const params = {
    TableName: "users",
    Key: {
      "username": {S: "test"}
    },
    ProjectionExpression: "username, password"
  };

  const user = await docClient.scan(params).promise();

  if (!user) {
    // return user not found to front-end
  }

  return user.Items[0].username;
}